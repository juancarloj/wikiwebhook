# dialogflow-wiki-webhook-sample
A simple node.js webhook for Google Dialogflow that does Wikipedia lookups and returns it to the bot
